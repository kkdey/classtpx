`bstick.decorana` <-
function(n, ...)
  stop("'bstick' not available for 'decorana'")

