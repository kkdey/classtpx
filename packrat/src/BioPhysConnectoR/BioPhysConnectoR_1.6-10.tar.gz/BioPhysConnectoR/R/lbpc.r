lbpc<-function(){
	ls("package:BioPhysConnectoR")
	}
