"%s%" <- function( x, y )
{
###
### This function is a wrapper the direct sum of two vectors or
### matrices resulting in a block diagonal matrix
###
### Arguments
### x = a numeric matrix or vector
### y = a numeric matrix or vector
###
    return( direct.sum( x, y ) )
}
