library(testthat)
library(ashr)

test_check("ashr")
